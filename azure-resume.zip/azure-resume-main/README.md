# azure-resume
My own azure resume, following ACG project video.

## First Steps
- Fround end folder contains the website.
- main.js contains visitor counter code.